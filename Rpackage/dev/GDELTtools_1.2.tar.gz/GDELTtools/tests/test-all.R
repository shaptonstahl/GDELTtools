library(testthat)

test_package("GDELTtools")
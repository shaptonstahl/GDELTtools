context("GetSizeOfGDELT")

test_that("returns valid size for GDELT", {
#  expect_true(GetSizeOfGDELT() > 0)
  expect_true(TRUE)
})

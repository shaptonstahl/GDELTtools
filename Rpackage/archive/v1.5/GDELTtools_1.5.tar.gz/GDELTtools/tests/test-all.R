library(testthat)

test_check("GDELTtools")